import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class GameWinWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class GameWinWorld extends World
{

    /**
     * Constructor for objects of class GameWinWorld.
     * 
     */
    public GameWinWorld()
    {    
        super(1260, 600, 1); 
        GreenfootImage backgroundImage = new GreenfootImage("lost.png");
        backgroundImage.scale(getWidth(), getHeight());
        setBackground(backgroundImage);
        Greenfoot.stop();
    }
}
