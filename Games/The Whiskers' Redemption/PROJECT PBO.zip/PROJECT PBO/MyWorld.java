import greenfoot.*;

public class MyWorld extends World
{
    public int money = 150;
    public int worldHealth = 10;
    public int temp = 0;
    public int time = 0;
    int map [][] =  {
                {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,6,0,0,0,0},
                {0,0,0,0,1,1,2,0,0,0,0,3,1,1,1,1,1,1,1,2,0},
                {0,0,0,0,0,6,1,0,0,0,0,1,6,0,0,0,0,0,0,1,0},
                {0,0,0,0,0,0,1,0,0,0,0,4,1,1,1,5,0,0,0,1,0},
                {0,0,0,0,0,0,1,0,0,0,0,0,0,0,6,1,0,0,0,1,6},
                {0,0,0,0,0,0,1,6,0,0,0,3,1,1,1,4,0,0,0,1,0},
                {0,0,0,0,0,0,1,0,0,0,0,1,0,0,0,0,0,0,0,1,0},
                {0,0,0,0,0,0,3,1,2,6,0,1,6,0,0,0,0,0,0,1,6},
                {0,0,0,0,0,0,0,0,3,1,1,4,0,0,0,0,0,0,0,1,0},
                {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0},
                };

    private static final int GRID_CELL_SIZE = 50; // Define your desired grid cell size

    public MyWorld(){    
        // Create a new world with 600x600 cells with the cell size specified by GRID_CELL_SIZE.
        super(1260, 600, 1); 
        displayPreparations();
        mapping();
    }
    
    public void act() {
        addTroops();
        spawnWave();
    }

    public int getMoney(){
        return money;
    }
    
    public void setMoney(int newMoney){
        money += newMoney;
    }
    
    public int getWorldHealth(){
        return worldHealth;
    }

    public void setNewWorldHealth(int newWorldHealth){
        worldHealth = newWorldHealth;
    }

    
    private void mapping(){
        for(int i = 0; i < 21; i++){
            for(int j = 0; j < 10; j++){
                if (map[j][i] == 1){
                    addObject(new Path(true), 30 + i * 60, 30 + j * 60);
                }
                if (map[j][i] == 2){
                    addObject(new Path(90), 30 + i * 60, 30 + j * 60);
                }
                if (map[j][i] == 3){
                    addObject(new Path(0), 30 + i * 60, 30 + j * 60);
                }
                if (map[j][i] == 4){
                    addObject(new Path(270), 30 + i * 60, 30 + j * 60);
                }
                if (map[j][i] == 5){
                    addObject(new Path(180), 30 + i * 60, 30 + j * 60);
                }
                if (map[j][i] == 6){
                    addObject(new RedCircle(), 30 + i * 60, 30 + j * 60);
                }
            }
        }
    }
    
    public void addTroops(){
        if(Greenfoot.isKeyDown("1") && money >= price(1) && Greenfoot.getMouseInfo().getActor() instanceof RedCircle){
            addObject(new Troop(1), (Greenfoot.getMouseInfo().getX() / 60) * 60 + 30, (Greenfoot.getMouseInfo().getY() / 60) * 60 + 10);
            money -= price(1); 
        }
        else if(Greenfoot.isKeyDown("2") && money >= price(2) && Greenfoot.getMouseInfo().getActor() instanceof RedCircle){
            addObject(new Troop(2), (Greenfoot.getMouseInfo().getX() / 60) * 60 + 30, (Greenfoot.getMouseInfo().getY() / 60) * 60 + 30);
            money -= price(2); 
        }
        else if(Greenfoot.isKeyDown("3") && money >= price(3) && Greenfoot.getMouseInfo().getActor() instanceof RedCircle){
            addObject(new Troop(3), (Greenfoot.getMouseInfo().getX() / 60) * 60 + 30, (Greenfoot.getMouseInfo().getY() / 60) * 60 + 30);
            money -= price(3); 
        }
    }
    
    public int price(int temp){
        if(temp == 1){
            return 50;
        }
        if(temp == 2){
            return 100;
        }
        if(temp == 3){
            return 150;
        }
        else{
           return 0; 
        }  
    }
    
    public void spawnWave(){
        time++;
        if(time >= 150){
            if(time < 2000 && time % 50 == 0){
                if(time % 150 != 0){
                    Enemy enemy1 = new Enemy(1, this);
                    addObject(enemy1, 270, 90);
                }
            }
            if(time < 12000 && time % 150 == 0){
                Enemy enemy2 = new Enemy(2, this);
                addObject(enemy2, 270, 90);
            }
            if(time > 2000 && time % 75 == 0){
                if(time % 150 != 0 && time % 120 != 0){
                    Enemy enemy2 = new Enemy(2, this);
                    addObject(enemy2, 270, 90);
                }
            }
            if(time > 2000 && time % 120 == 0){
                Enemy enemy3 = new Enemy(3, this);
                addObject(enemy3, 270, 90);
            }
            if(time > 12000 && time % 150 == 0){
                Enemy enemy3 = new Enemy(3, this);
                addObject(enemy3, 270, 90);
            }
            if(time >= 18000){
                Greenfoot.setWorld(new GameWinWorld());
                Greenfoot.stop();
            }
            if(time >= 10000 && time <= 11000 && time % 20 == 0){
                Enemy enemy1 = new Enemy(1, this);
                addObject(enemy1, 270, 90);
            }
        }
        
    }
    
    public void displayPreparations(){
        Menu menu = new Menu();
        DisplayMoney dMoney = new DisplayMoney(this);
        DisplayCat displaybowcat = new DisplayCat(1);
        DisplayCat displayguncat = new DisplayCat(2);
        DisplayCat displaywizardcat = new DisplayCat(3);
        DisplayTextInfo displaytextinfo = new DisplayTextInfo(1, this);
        DisplayTextInfo displayprice1 = new DisplayTextInfo(2, this);
        DisplayTextInfo displayprice2 = new DisplayTextInfo(3, this);
        DisplayTextInfo displayprice3 = new DisplayTextInfo(4, this);
        DisplayTextInfo displayhealth = new DisplayTextInfo(5, this);
        addObject(menu, 120, 300);
        addObject(dMoney, 120, 25);
        addObject(displaybowcat, 120, 115);
        addObject(displayguncat, 120, 250);
        addObject(displaywizardcat, 120, 385);
        addObject(displaytextinfo, 120, 70);
        addObject(displayprice1, 115, 160);
        addObject(displayprice2, 115, 295);
        addObject(displayprice3, 115, 430);
        addObject(displayhealth, 115, 510);
    }   
}