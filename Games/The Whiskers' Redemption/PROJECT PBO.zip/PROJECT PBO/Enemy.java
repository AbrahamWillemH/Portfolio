import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.*;
/**
 * Write a description of class Ghost here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Enemy extends Actor
{
    /**
     * Act - do whatever the Ghost wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    private int enemy_health;
    private int level;
    private MyWorld game;
    public Enemy(int level, MyWorld game){
        this.level = level;
        this.game = game;
        if(level == 1){
            setImage("mousefinal.png");
            getImage().scale(60, 60);
            enemy_health = 5;
        }
        else if(level == 2){
            setImage("zombiecatfinal.png");
            getImage().scale(40, 40);
            enemy_health = 13;
        }
        else if(level == 3){
            setImage("ghostfinal.png");
            getImage().scale(60, 60);
            enemy_health = 21;
        }
    }
    public void act()
    {
        moveEnemy();
        hitByProjectile();
        isFinish(game);
    }
    public void moveEnemy(){
        move(2);
        List <Path> path90 = getObjectsAtOffset(-30, 0, Path.class);
        for(Path paths : path90){
            if(paths.straight == false && getRotation() == 0){
                setRotation(paths.turn);
            }
        }
        List <Path> path0 = getObjectsAtOffset(0, -30, Path.class);
        for(Path paths : path0){
            if(paths.straight == false && getRotation() == 90){
                setRotation(paths.turn);
            }
        }
        List <Path> path270 = getObjectsAtOffset(+30, 0, Path.class);
        for(Path paths : path270){
            if(paths.straight == false && getRotation() == 180){
                setRotation(paths.turn);
            }
        }
        List <Path> path180 = getObjectsAtOffset(0, +30, Path.class);
        for(Path paths : path180){
            if(paths.straight == false && getRotation() == 270){
                setRotation(paths.turn);
            }
        }
    }
    public void hitByProjectile() {
    Actor projectile = getOneIntersectingObject(Projectile.class);
    if (projectile != null) {
        enemy_health--;
        if (enemy_health < 1) {
            World world = getWorld();
            if (world != null) {
                world.removeObject(this);
                if(level == 1)
                    game.setMoney(4);
                if(level == 2)
                    game.setMoney(8);
                if(level == 3)
                    game.setMoney(16);
            }
        }
        if (projectile.getWorld() != null) {
            projectile.getWorld().removeObject(projectile);
        }
    }
    }

    public void isFinish(MyWorld game){
        this.game = game;
        if(this.getWorld() != null && getX() == 1170 && getY() == 599){
            getWorld().removeObject(this);
            game.worldHealth--;
            if(game.worldHealth <= 0){
                Greenfoot.setWorld(new GameOverWorld());
            }
        }
    }
}
    
